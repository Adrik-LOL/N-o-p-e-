const Discord = require("discord.js");
const config = require("./config.json");
const client = new Discord.Client();
const prefix = "s.";
client.login(config.BOT_TOKEN);

client.on("message", message => {
    if (message.content.toLowerCase().includes("s.mcplay")) { // Note that this is an example and anyone can use this command.

        message.channel.send("mc.bruh.fun ver: 1.16.4").then(() => {

        })

    }

});

client.on("message", message => {
    if (message.content.toLowerCase().includes("s.byebye")) { // Note that this is an example and anyone can use this command.

        message.channel.send("Shutting down...").then(() => {

            client.destroy();

        })

    }

});

client.on("message", message => {
    if (message.content.toLowerCase().includes("s.spam")) { // Note that this is an example and anyone can use this command.

        message.channel.send("@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH@everyone BRUH").then(() => {
            

        
        })

    }

});    

client.on("message", message => {
    if (message.content.toLowerCase().includes("s.hi")) { // Note that this is an example and anyone can use this command.

        message.channel.send("HI :), Nice to meet you").then(() => {


        })

    }

});